AI Camera Shortcuts V3

1. Copy install_shortcuts_v3.sh into:
   /home/toto/AI_CAMERA_TEST_YOLO_ROI

2. Run:
   chmod +x install_shortcuts_v3.sh
   ./install_shortcuts_v3.sh

3. Double-click AI Camera Main on Desktop and choose Execute.

If the app does not open, check:
   cat launcher_logs/main_app_$(date +%Y%m%d).log
