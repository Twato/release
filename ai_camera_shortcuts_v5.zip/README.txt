AI Camera Shortcuts V5

Behavior:
- AI Camera Main starts Mock_API_V1/app.py when needed.
- The launcher records the Mock API process group.
- When T55.py closes, the launcher stops that Mock API process group.
- If Mock API was already running before Main opened, the launcher leaves it running.
- AI Camera Search remains independent.

Install:
  chmod +x install_shortcuts_v5.sh
  ./install_shortcuts_v5.sh

Check API after closing Main:
  pgrep -af '/Mock_API_V1/app.py'

Logs:
  launcher_logs/main_app_YYYYMMDD.log
  launcher_logs/mock_api_YYYYMMDD.log
