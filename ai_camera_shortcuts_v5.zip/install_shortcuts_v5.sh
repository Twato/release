#!/usr/bin/env bash
set -u

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $# -ge 1 && -d "$1" ]]; then
    PROJECT_DIR="$(cd "$1" && pwd)"
fi

DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
if [[ -z "$DESKTOP_DIR" || ! -d "$DESKTOP_DIR" ]]; then
    DESKTOP_DIR="$HOME/Desktop"
fi
mkdir -p "$DESKTOP_DIR"

PYTHON_BIN="$(command -v python3)"
LOG_DIR="$PROJECT_DIR/launcher_logs"
mkdir -p "$LOG_DIR"

find_first_file() {
    local candidate
    for candidate in "$@"; do
        if [[ -f "$PROJECT_DIR/$candidate" ]]; then
            printf '%s' "$candidate"
            return 0
        fi
    done
    return 1
}

MAIN_FILE="$(find_first_file \
    'T55.py' \
    'T55(1).py' \
    'T55_PRODUCTION_HMI_FINAL_UI.py' \
    2>/dev/null || true)"

SEARCH_FILE="$(find_first_file \
    'Evidence_Viewer.py' \
    'evidence_viewer.py' \
    'Search.py' \
    'search.py' \
    2>/dev/null || true)"

MOCK_API_DIR="$PROJECT_DIR/Mock_API_V1"
MOCK_API_FILE="$MOCK_API_DIR/app.py"

create_main_runner() {
    local runner="$PROJECT_DIR/run_ai_camera_main.sh"

    cat > "$runner" <<'RUNNER'
#!/usr/bin/env bash
set -u

PROJECT_DIR="__PROJECT_DIR__"
PYTHON_BIN="__PYTHON_BIN__"
PY_FILE="__MAIN_FILE__"
MOCK_API_DIR="$PROJECT_DIR/Mock_API_V1"
MOCK_API_FILE="$MOCK_API_DIR/app.py"
LOG_DIR="$PROJECT_DIR/launcher_logs"

mkdir -p "$LOG_DIR"
cd "$PROJECT_DIR" || exit 1

LOCK_FILE="/tmp/ai_camera_main_app.lock"
exec 9>"$LOCK_FILE"

if ! flock -n 9; then
    zenity --info \
        --title="AI Camera" \
        --text="AI Camera Main is already open." \
        2>/dev/null || true
    exit 0
fi

MAIN_LOG="$LOG_DIR/main_app_$(date +%Y%m%d).log"
API_LOG="$LOG_DIR/mock_api_$(date +%Y%m%d).log"

MOCK_API_STARTED_BY_LAUNCHER=0
MOCK_API_PID=""

cleanup_mock_api() {
    if [[ "$MOCK_API_STARTED_BY_LAUNCHER" -eq 1 && -n "$MOCK_API_PID" ]]; then
        echo "Stopping Mock API process group: $MOCK_API_PID" >>"$API_LOG"

        # Stop the complete process group, including Flask reloader child processes.
        kill -TERM -- "-$MOCK_API_PID" 2>/dev/null || true

        for _ in 1 2 3 4 5; do
            if ! kill -0 "$MOCK_API_PID" 2>/dev/null; then
                break
            fi
            sleep 0.3
        done

        kill -KILL -- "-$MOCK_API_PID" 2>/dev/null || true
        wait "$MOCK_API_PID" 2>/dev/null || true
        echo "Mock API stopped." >>"$API_LOG"
    fi
}

trap cleanup_mock_api EXIT INT TERM HUP

if [[ ! -f "$MOCK_API_FILE" ]]; then
    zenity --error \
        --title="Mock API Error" \
        --text="Mock API file not found:

$MOCK_API_FILE" \
        2>/dev/null || true
    exit 1
fi

# Start the Mock API only when another instance is not already running.
if ! pgrep -f "$MOCK_API_FILE" >/dev/null 2>&1; then
    (
        cd "$MOCK_API_DIR" || exit 1
        exec setsid "$PYTHON_BIN" "$MOCK_API_FILE"
    ) >>"$API_LOG" 2>&1 &

    MOCK_API_PID=$!
    MOCK_API_STARTED_BY_LAUNCHER=1

    echo "Mock API started by launcher. PID/PGID: $MOCK_API_PID" >>"$API_LOG"
    sleep 2

    if ! kill -0 "$MOCK_API_PID" 2>/dev/null; then
        zenity --error \
            --title="Mock API Error" \
            --text="Mock API could not start.

Check log:
$API_LOG" \
            2>/dev/null || true
        exit 1
    fi
else
    echo "Mock API was already running. Launcher will not stop it." >>"$API_LOG"
fi

"$PYTHON_BIN" "$PROJECT_DIR/$PY_FILE" >>"$MAIN_LOG" 2>&1
EXIT_CODE=$?

if [[ "$EXIT_CODE" -ne 0 ]]; then
    zenity --error \
        --title="AI Camera Error" \
        --text="Application could not start.

Check log:
$MAIN_LOG" \
        2>/dev/null || true
fi

# EXIT trap stops Mock API only when this launcher started it.
exit "$EXIT_CODE"
RUNNER

    sed -i \
        -e "s|__PROJECT_DIR__|$PROJECT_DIR|g" \
        -e "s|__PYTHON_BIN__|$PYTHON_BIN|g" \
        -e "s|__MAIN_FILE__|$MAIN_FILE|g" \
        "$runner"

    chmod +x "$runner"
}

create_search_runner() {
    local runner="$PROJECT_DIR/run_ai_camera_search.sh"

    cat > "$runner" <<'RUNNER'
#!/usr/bin/env bash
set -u

PROJECT_DIR="__PROJECT_DIR__"
PYTHON_BIN="__PYTHON_BIN__"
PY_FILE="__SEARCH_FILE__"
LOG_DIR="$PROJECT_DIR/launcher_logs"

mkdir -p "$LOG_DIR"
cd "$PROJECT_DIR" || exit 1

LOCK_FILE="/tmp/ai_camera_search_app.lock"
exec 9>"$LOCK_FILE"

if ! flock -n 9; then
    zenity --info \
        --title="AI Camera Search" \
        --text="AI Camera Search is already open." \
        2>/dev/null || true
    exit 0
fi

LOG_FILE="$LOG_DIR/search_app_$(date +%Y%m%d).log"

"$PYTHON_BIN" "$PROJECT_DIR/$PY_FILE" >>"$LOG_FILE" 2>&1
EXIT_CODE=$?

if [[ "$EXIT_CODE" -ne 0 ]]; then
    zenity --error \
        --title="AI Camera Search Error" \
        --text="Search application could not start.

Check log:
$LOG_FILE" \
        2>/dev/null || true
fi

exit "$EXIT_CODE"
RUNNER

    sed -i \
        -e "s|__PROJECT_DIR__|$PROJECT_DIR|g" \
        -e "s|__PYTHON_BIN__|$PYTHON_BIN|g" \
        -e "s|__SEARCH_FILE__|$SEARCH_FILE|g" \
        "$runner"

    chmod +x "$runner"
}

create_desktop_file() {
    local path="$1"
    local name="$2"
    local comment="$3"
    local exec_path="$4"
    local icon="$5"

    cat > "$path" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=$name
Comment=$comment
Exec=$exec_path
Path=$PROJECT_DIR
Icon=$icon
Terminal=false
Categories=Utility;
StartupNotify=true
DESKTOP

    chmod +x "$path"
    gio set "$path" metadata::trusted true 2>/dev/null || true
}

ERRORS=0

if [[ -z "$MAIN_FILE" ]]; then
    echo "[ERROR] Main application file not found."
    ERRORS=$((ERRORS + 1))
elif [[ ! -f "$MOCK_API_FILE" ]]; then
    echo "[ERROR] Mock API not found: $MOCK_API_FILE"
    ERRORS=$((ERRORS + 1))
else
    create_main_runner

    create_desktop_file \
        "$DESKTOP_DIR/AI Camera Main.desktop" \
        "AI Camera Main" \
        "Start Mock API and AI Camera Main; stop API when Main closes" \
        "$PROJECT_DIR/run_ai_camera_main.sh" \
        "camera-photo"

    echo "[OK] Main shortcut created"
fi

if [[ -z "$SEARCH_FILE" ]]; then
    echo "[WARNING] Search application file not found."
    ERRORS=$((ERRORS + 1))
else
    create_search_runner

    create_desktop_file \
        "$DESKTOP_DIR/AI Camera Search.desktop" \
        "AI Camera Search" \
        "Open AI Camera evidence search" \
        "$PROJECT_DIR/run_ai_camera_search.sh" \
        "system-search"

    echo "[OK] Search shortcut created"
fi

echo
echo "Python: $PYTHON_BIN"
echo "Project: $PROJECT_DIR"
echo "Mock API: $MOCK_API_FILE"
echo "Logs: $LOG_DIR"

if [[ "$ERRORS" -eq 0 ]]; then
    zenity --info \
        --title="AI Camera Shortcuts V5" \
        --text="Shortcuts created.

AI Camera Main starts Mock API automatically.
When Main App closes, that Mock API process is stopped automatically." \
        2>/dev/null || true
    exit 0
fi

zenity --warning \
    --title="AI Camera Shortcuts V5" \
    --text="Installation finished with warnings. Check terminal output." \
    2>/dev/null || true

exit 1
