AI Camera Shortcuts V4

Main behavior:
- Starts /home/toto/AI_CAMERA_TEST_YOLO_ROI/Mock_API_V1/app.py automatically
- Waits 2 seconds
- Opens T55.py
- Does not start a duplicate Mock API process

Installation:
1. Copy install_shortcuts_v4.sh into:
   /home/toto/AI_CAMERA_TEST_YOLO_ROI

2. Run:
   chmod +x install_shortcuts_v4.sh
   ./install_shortcuts_v4.sh

Desktop shortcuts:
- AI Camera Main
- AI Camera Search
- AI Camera Mock API

Logs:
- launcher_logs/main_app_YYYYMMDD.log
- launcher_logs/search_app_YYYYMMDD.log
- launcher_logs/mock_api_YYYYMMDD.log
