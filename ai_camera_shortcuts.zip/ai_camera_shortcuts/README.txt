AI CAMERA SHORTCUT INSTALLER

Recommended project files:
- T55.py                  Main production application
- Evidence_Viewer.py      Search / evidence application

INSTALL ON RASPBERRY PI
1. Copy install_shortcuts.sh into /home/toto1/AI_camera
2. Open Terminal in that folder.
3. Run:

   chmod +x install_shortcuts.sh
   ./install_shortcuts.sh

Or run it from any folder and give the project path:

   bash install_shortcuts.sh /home/toto1/AI_camera

The installer creates:
- Desktop/AI Camera Main.desktop
- Desktop/AI Camera Search.desktop
- run_ai_camera_main.sh
- run_ai_camera_search.sh
- launcher_logs/

Notes:
- The installer automatically uses .venv/bin/python or venv/bin/python when present.
- Otherwise it uses python3.
- Each app is limited to one open instance.
- Startup errors are saved under launcher_logs.
- If Raspberry Pi asks whether to execute the desktop file, choose Execute.
