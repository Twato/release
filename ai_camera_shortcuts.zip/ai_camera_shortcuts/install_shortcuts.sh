#!/usr/bin/env bash
set -u

# Run this installer from inside the AI_camera project folder.
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# If this installer is inside a downloaded helper folder, allow the project path
# to be passed as the first argument:
#   bash install_shortcuts.sh /home/toto1/AI_camera
if [[ $# -ge 1 && -d "$1" ]]; then
    PROJECT_DIR="$(cd "$1" && pwd)"
fi

DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
if [[ -z "$DESKTOP_DIR" || ! -d "$DESKTOP_DIR" ]]; then
    DESKTOP_DIR="$HOME/Desktop"
fi
mkdir -p "$DESKTOP_DIR"

LOG_DIR="$PROJECT_DIR/launcher_logs"
mkdir -p "$LOG_DIR"

find_first_file() {
    local candidate
    for candidate in "$@"; do
        if [[ -f "$PROJECT_DIR/$candidate" ]]; then
            printf '%s' "$candidate"
            return 0
        fi
    done
    return 1
}

MAIN_FILE="$(find_first_file \
    'T55.py' \
    'T55(1).py' \
    'T55_PRODUCTION_HMI_FINAL_UI.py' \
    2>/dev/null || true)"

SEARCH_FILE="$(find_first_file \
    'Evidence_Viewer.py' \
    'evidence_viewer.py' \
    'Search.py' \
    'search.py' \
    2>/dev/null || true)"

choose_python() {
    if [[ -x "$PROJECT_DIR/.venv/bin/python" ]]; then
        printf '%s' "$PROJECT_DIR/.venv/bin/python"
    elif [[ -x "$PROJECT_DIR/venv/bin/python" ]]; then
        printf '%s' "$PROJECT_DIR/venv/bin/python"
    else
        command -v python3
    fi
}

PYTHON_BIN="$(choose_python)"

create_runner() {
    local runner_path="$1"
    local py_file="$2"
    local log_name="$3"

    cat > "$runner_path" <<RUNNER
#!/usr/bin/env bash
set -u
PROJECT_DIR=$(printf '%q' "$PROJECT_DIR")
PYTHON_BIN=$(printf '%q' "$PYTHON_BIN")
PY_FILE=$(printf '%q' "$py_file")
LOG_DIR=\"\$PROJECT_DIR/launcher_logs\"
mkdir -p \"\$LOG_DIR\"
cd \"\$PROJECT_DIR\" || exit 1

# Keep one instance per application.
LOCK_FILE=\"/tmp/ai_camera_${log_name}.lock\"
exec 9>\"\$LOCK_FILE\"
if ! flock -n 9; then
    zenity --info --title=\"AI Camera\" --text=\"This application is already open.\" 2>/dev/null || true
    exit 0
fi

\"\$PYTHON_BIN\" \"\$PROJECT_DIR/\$PY_FILE\" >> \"\$LOG_DIR/${log_name}_\$(date +%Y%m%d).log\" 2>&1
EXIT_CODE=\$?

if [[ \$EXIT_CODE -ne 0 ]]; then
    MESSAGE=\"Application could not start.\\n\\nCheck log:\\n\$LOG_DIR/${log_name}_\$(date +%Y%m%d).log\"
    zenity --error --title=\"AI Camera Error\" --text=\"\$MESSAGE\" 2>/dev/null || true
fi
exit \$EXIT_CODE
RUNNER
    chmod +x "$runner_path"
}

create_desktop_file() {
    local desktop_path="$1"
    local app_name="$2"
    local comment="$3"
    local runner_path="$4"
    local icon="$5"

    cat > "$desktop_path" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=$app_name
Comment=$comment
Exec=$runner_path
Icon=$icon
Terminal=false
Categories=Utility;
StartupNotify=true
DESKTOP
    chmod +x "$desktop_path"
    gio set "$desktop_path" metadata::trusted true 2>/dev/null || true
}

ERRORS=0

if [[ -n "$MAIN_FILE" ]]; then
    MAIN_RUNNER="$PROJECT_DIR/run_ai_camera_main.sh"
    create_runner "$MAIN_RUNNER" "$MAIN_FILE" "main_app"
    create_desktop_file \
        "$DESKTOP_DIR/AI Camera Main.desktop" \
        "AI Camera Main" \
        "Open the AI Camera production application" \
        "$MAIN_RUNNER" \
        "camera-photo"
    echo "[OK] Main shortcut: $DESKTOP_DIR/AI Camera Main.desktop"
    echo "     Main file: $PROJECT_DIR/$MAIN_FILE"
else
    echo "[ERROR] Main file not found in: $PROJECT_DIR"
    echo "        Expected T55.py or T55(1).py"
    ERRORS=$((ERRORS + 1))
fi

if [[ -n "$SEARCH_FILE" ]]; then
    SEARCH_RUNNER="$PROJECT_DIR/run_ai_camera_search.sh"
    create_runner "$SEARCH_RUNNER" "$SEARCH_FILE" "search_app"
    create_desktop_file \
        "$DESKTOP_DIR/AI Camera Search.desktop" \
        "AI Camera Search" \
        "Open the AI Camera evidence search application" \
        "$SEARCH_RUNNER" \
        "system-search"
    echo "[OK] Search shortcut: $DESKTOP_DIR/AI Camera Search.desktop"
    echo "     Search file: $PROJECT_DIR/$SEARCH_FILE"
else
    echo "[WARNING] Search application was not found in: $PROJECT_DIR"
    echo "          Expected Evidence_Viewer.py (recommended filename)"
    ERRORS=$((ERRORS + 1))
fi

echo
echo "Python: $PYTHON_BIN"
echo "Project: $PROJECT_DIR"
echo "Logs: $LOG_DIR"

if [[ $ERRORS -eq 0 ]]; then
    zenity --info --title="AI Camera Shortcuts" --text="Main and Search shortcuts were created on the Desktop." 2>/dev/null || true
    exit 0
fi

zenity --warning --title="AI Camera Shortcuts" --text="Installation finished, but one or more application files were not found. Check the terminal output." 2>/dev/null || true
exit 1
