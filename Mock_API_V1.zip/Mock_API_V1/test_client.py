import requests

API_BASE_URL = "http://127.0.0.1:5000"


def get_picking(delivery_no):
    url = f"{API_BASE_URL}/api/picking"
    payload = {"delivery_no": delivery_no}
    r = requests.post(url, json=payload, timeout=5)
    print("STATUS:", r.status_code)
    print(r.json())


def validate_vendor_box(delivery_no, inner_index, vendor_box_id):
    url = f"{API_BASE_URL}/api/validate/vendor-box"
    payload = {
        "delivery_no": delivery_no,
        "inner_index": inner_index,
        "vendor_box_id": vendor_box_id
    }
    r = requests.post(url, json=payload, timeout=5)
    print("STATUS:", r.status_code)
    print(r.json())


if __name__ == "__main__":
    get_picking("0001091921")
    validate_vendor_box("0001091921", 1, "LT41T266280073")
    validate_vendor_box("0001091921", 2, "WRONG_BOX_ID")
