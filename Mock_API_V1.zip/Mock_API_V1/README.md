# Mock_API_V1

Mock API สำหรับ AI-Based Validation System for Shipping Label Verification

## Flow

Application ยิง Delivery No ไปหา Mock API

```text
Scan Delivery No
        ↓
POST /api/picking
        ↓
Return Item No, Quantity, BOX ID List
```

## Install

```bash
pip install flask requests
```

## Run API

```bash
cd Mock_API_V1
python app.py
```

API จะรันที่

```text
http://0.0.0.0:5000
```

ถ้ารันใน Raspberry Pi เครื่องเดียวกับ T30 ให้ใช้

```text
http://127.0.0.1:5000
```

ถ้ารันคนละเครื่อง ให้ใช้ IP ของเครื่อง API เช่น

```text
http://10.136.xxx.xxx:5000
```

## Test Health

```bash
curl http://127.0.0.1:5000/api/health
```

## Test Picking

```bash
curl -X POST http://127.0.0.1:5000/api/picking \
  -H "Content-Type: application/json" \
  -d '{"delivery_no":"0001091921"}'
```

Response:

```json
{
  "success": true,
  "message": "OK",
  "data": {
    "delivery_no": "0001091921",
    "item_no": "000001",
    "quantity": 6,
    "box_ids": [
      "LT41T266280073",
      "LT41T266280074",
      "LT41T266280075",
      "LT41T266280076",
      "LT41T266280077",
      "LT41T266280078"
    ]
  }
}
```

## Test Vendor BOX ID Validation

```bash
curl -X POST http://127.0.0.1:5000/api/validate/vendor-box \
  -H "Content-Type: application/json" \
  -d '{"delivery_no":"0001091921","inner_index":1,"vendor_box_id":"LT41T266280073"}'
```

## Files

```text
Mock_API_V1/
  app.py
  mock_db.json
  test_client.py
  t30_api_client_helper.py
  README.md
```

## Keyboard + Scanner Input

Barcode Scanner แบบ USB HID ทำงานเหมือน Keyboard
ดังนั้นใน Tkinter Entry ใช้รับได้ทั้งสองแบบ

แนะนำให้ bind `<Return>`:

```python
en_entry.bind("<Return>", lambda e: delivery_entry.focus_set())
delivery_entry.bind("<Return>", lambda e: start_job())
```

และก่อนส่ง API ให้ normalize:

```python
delivery_no = delivery_entry.get().strip().replace(" ", "").upper()
```
