"""
Helper สำหรับเอาไปใส่ใน T30
ต้องติดตั้ง requests ก่อน:
    pip install requests
"""

import requests

MOCK_API_BASE_URL = "http://127.0.0.1:5000"


def normalize_scan_text(value):
    """รองรับ Keyboard + Barcode Scanner: ตัด Enter/Tab/Space และแปลงเป็นตัวพิมพ์ใหญ่"""
    return str(value or "").strip().replace(" ", "").upper()


def fetch_picking_from_mock_api(delivery_no, timeout=5):
    delivery_no = normalize_scan_text(delivery_no)
    if not delivery_no:
        return False, "Delivery No is empty", None

    try:
        url = f"{MOCK_API_BASE_URL}/api/picking"
        response = requests.post(url, json={"delivery_no": delivery_no}, timeout=timeout)
        data = response.json()

        if response.status_code != 200 or not data.get("success"):
            return False, data.get("message", "API Error"), None

        picking = data.get("data", {})
        return True, "OK", picking

    except requests.exceptions.RequestException as e:
        return False, f"Cannot connect Mock API: {e}", None
    except Exception as e:
        return False, f"Mock API error: {e}", None


def validate_vendor_box_with_mock_api(delivery_no, inner_index, vendor_box_id, timeout=5):
    try:
        url = f"{MOCK_API_BASE_URL}/api/validate/vendor-box"
        payload = {
            "delivery_no": normalize_scan_text(delivery_no),
            "inner_index": int(inner_index),
            "vendor_box_id": normalize_scan_text(vendor_box_id),
        }
        response = requests.post(url, json=payload, timeout=timeout)
        data = response.json()
        if response.status_code != 200 or not data.get("success"):
            return False, data.get("message", "API Error"), None
        return True, "OK", data
    except Exception as e:
        return False, str(e), None
