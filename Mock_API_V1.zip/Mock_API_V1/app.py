from flask import Flask, jsonify, request
from pathlib import Path
from datetime import datetime
import json

APP_VERSION = "Mock_API_V1"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "mock_db.json"

app = Flask(__name__)


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def normalize_text(value):
    return str(value or "").strip().replace(" ", "").upper()


def load_db():
    if not DB_PATH.exists():
        return {"deliveries": []}
    with DB_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def find_delivery(delivery_no):
    db = load_db()
    target = normalize_text(delivery_no)
    for row in db.get("deliveries", []):
        if normalize_text(row.get("delivery_no")) == target:
            box_ids = row.get("box_ids", []) or []
            quantity = int(row.get("quantity", len(box_ids)) or len(box_ids))
            return {
                "delivery_no": str(row.get("delivery_no", "")),
                "item_no": str(row.get("item_no", "")),
                "quantity": quantity,
                "box_ids": [str(x) for x in box_ids]
            }
    return None


@app.get("/api/health")
def health():
    return jsonify({
        "success": True,
        "version": APP_VERSION,
        "status": "ONLINE",
        "time": now_iso()
    })


@app.post("/api/picking")
def picking():
    payload = request.get_json(silent=True) or {}
    delivery_no = payload.get("delivery_no", "")

    if not normalize_text(delivery_no):
        return jsonify({
            "success": False,
            "message": "Delivery No is required",
            "time": now_iso()
        }), 400

    data = find_delivery(delivery_no)
    if data is None:
        return jsonify({
            "success": False,
            "message": "Delivery Not Found",
            "delivery_no": str(delivery_no),
            "time": now_iso()
        }), 404

    if data["quantity"] != len(data["box_ids"]):
        return jsonify({
            "success": False,
            "message": "Mock data error: quantity does not match box_ids count",
            "delivery_no": data["delivery_no"],
            "quantity": data["quantity"],
            "box_id_count": len(data["box_ids"]),
            "time": now_iso()
        }), 500

    return jsonify({
        "success": True,
        "message": "OK",
        "data": data,
        "time": now_iso()
    })


@app.post("/api/validate/vendor-box")
def validate_vendor_box():
    payload = request.get_json(silent=True) or {}
    delivery_no = payload.get("delivery_no", "")
    inner_index = int(payload.get("inner_index", 0) or 0)
    ocr_vendor_box_id = payload.get("vendor_box_id", "")

    data = find_delivery(delivery_no)
    if data is None:
        return jsonify({"success": False, "message": "Delivery Not Found"}), 404

    if inner_index < 1 or inner_index > len(data["box_ids"]):
        return jsonify({
            "success": False,
            "message": "Inner index out of range",
            "quantity": data["quantity"]
        }), 400

    expected = data["box_ids"][inner_index - 1]
    is_match = normalize_text(expected) == normalize_text(ocr_vendor_box_id)

    return jsonify({
        "success": True,
        "result": "PASS" if is_match else "FAIL",
        "delivery_no": data["delivery_no"],
        "inner_index": inner_index,
        "expected_box_id": expected,
        "ocr_vendor_box_id": str(ocr_vendor_box_id),
        "message": "BOX ID MATCH" if is_match else "BOX ID NOT MATCH",
        "time": now_iso()
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
