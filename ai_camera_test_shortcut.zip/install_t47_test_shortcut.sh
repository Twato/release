#!/usr/bin/env bash
set -u

PROJECT_DIR="/home/toto/AI_CAMERA_TEST_YOLO_ROI"
DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"

if [[ -z "$DESKTOP_DIR" || ! -d "$DESKTOP_DIR" ]]; then
    DESKTOP_DIR="$HOME/Desktop"
fi

mkdir -p "$DESKTOP_DIR"
mkdir -p "$PROJECT_DIR/launcher_logs"

PYTHON_BIN="$(command -v python3)"

find_test_file() {
    local candidate
    for candidate in \
        "T47_Maintest_UI.py" \
        "T47_MainTest_UI.py" \
        "T47_Maintest_UI" \
        "T47.py"
    do
        if [[ -f "$PROJECT_DIR/$candidate" ]]; then
            printf '%s' "$candidate"
            return 0
        fi
    done
    return 1
}

TEST_FILE="$(find_test_file 2>/dev/null || true)"

if [[ -z "$TEST_FILE" ]]; then
    echo "[ERROR] Test application file not found in:"
    echo "        $PROJECT_DIR"
    echo
    echo "Expected one of:"
    echo "  T47_Maintest_UI.py"
    echo "  T47_MainTest_UI.py"
    echo "  T47.py"
    exit 1
fi

RUNNER="$PROJECT_DIR/run_ai_camera_test.sh"

cat > "$RUNNER" <<'RUNNER'
#!/usr/bin/env bash
set -u

PROJECT_DIR="/home/toto/AI_CAMERA_TEST_YOLO_ROI"
PYTHON_BIN="__PYTHON_BIN__"
PY_FILE="__TEST_FILE__"
MOCK_API_DIR="$PROJECT_DIR/Mock_API_V1"
MOCK_API_FILE="$MOCK_API_DIR/app.py"
LOG_DIR="$PROJECT_DIR/launcher_logs"

mkdir -p "$LOG_DIR"
cd "$PROJECT_DIR" || exit 1

LOCK_FILE="/tmp/ai_camera_test_app.lock"
exec 9>"$LOCK_FILE"

if ! flock -n 9; then
    zenity --info \
        --title="AI Camera Test" \
        --text="AI Camera Test is already open." \
        2>/dev/null || true
    exit 0
fi

TEST_LOG="$LOG_DIR/test_app_$(date +%Y%m%d).log"
API_LOG="$LOG_DIR/mock_api_$(date +%Y%m%d).log"

MOCK_API_STARTED_BY_TEST=0
MOCK_API_PID=""

cleanup_mock_api() {
    if [[ "$MOCK_API_STARTED_BY_TEST" -eq 1 && -n "$MOCK_API_PID" ]]; then
        echo "Stopping Mock API started by AI Camera Test. PID/PGID: $MOCK_API_PID" >>"$API_LOG"

        kill -TERM -- "-$MOCK_API_PID" 2>/dev/null || true

        for _ in 1 2 3 4 5; do
            if ! kill -0 "$MOCK_API_PID" 2>/dev/null; then
                break
            fi
            sleep 0.3
        done

        kill -KILL -- "-$MOCK_API_PID" 2>/dev/null || true
        wait "$MOCK_API_PID" 2>/dev/null || true

        echo "Mock API stopped by AI Camera Test launcher." >>"$API_LOG"
    fi
}

trap cleanup_mock_api EXIT INT TERM HUP

if [[ ! -f "$MOCK_API_FILE" ]]; then
    zenity --error \
        --title="Mock API Error" \
        --text="Mock API file not found:

$MOCK_API_FILE" \
        2>/dev/null || true
    exit 1
fi

# Reuse an API already opened by T55, the test app, or Terminal.
if ! pgrep -f "$MOCK_API_FILE" >/dev/null 2>&1; then
    (
        cd "$MOCK_API_DIR" || exit 1
        exec setsid "$PYTHON_BIN" "$MOCK_API_FILE"
    ) >>"$API_LOG" 2>&1 &

    MOCK_API_PID=$!
    MOCK_API_STARTED_BY_TEST=1

    echo "Mock API started by AI Camera Test. PID/PGID: $MOCK_API_PID" >>"$API_LOG"
    sleep 2

    if ! kill -0 "$MOCK_API_PID" 2>/dev/null; then
        zenity --error \
            --title="Mock API Error" \
            --text="Mock API could not start.

Check log:
$API_LOG" \
            2>/dev/null || true
        exit 1
    fi
else
    echo "Mock API was already running. AI Camera Test will reuse it and will not stop it." >>"$API_LOG"
fi

"$PYTHON_BIN" "$PROJECT_DIR/$PY_FILE" >>"$TEST_LOG" 2>&1
EXIT_CODE=$?

if [[ "$EXIT_CODE" -ne 0 ]]; then
    zenity --error \
        --title="AI Camera Test Error" \
        --text="Test application could not start.

Check log:
$TEST_LOG" \
        2>/dev/null || true
fi

exit "$EXIT_CODE"
RUNNER

sed -i \
    -e "s|__PYTHON_BIN__|$PYTHON_BIN|g" \
    -e "s|__TEST_FILE__|$TEST_FILE|g" \
    "$RUNNER"

chmod +x "$RUNNER"

DESKTOP_FILE="$DESKTOP_DIR/AI Camera Test.desktop"

cat > "$DESKTOP_FILE" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=AI Camera Test
Comment=Open T47 Main Test UI with Mock API
Exec=$RUNNER
Path=$PROJECT_DIR
Icon=applications-development
Terminal=false
Categories=Utility;
StartupNotify=true
DESKTOP

chmod +x "$DESKTOP_FILE"
gio set "$DESKTOP_FILE" metadata::trusted true 2>/dev/null || true

echo "[OK] AI Camera Test shortcut created:"
echo "     $DESKTOP_FILE"
echo
echo "Test file: $PROJECT_DIR/$TEST_FILE"
echo "Python: $PYTHON_BIN"
echo "Mock API: $PROJECT_DIR/Mock_API_V1/app.py"
echo "Logs: $PROJECT_DIR/launcher_logs"

zenity --info \
    --title="AI Camera Test Shortcut" \
    --text="AI Camera Test shortcut was created on the Desktop.

It will start or reuse Mock API automatically." \
    2>/dev/null || true
