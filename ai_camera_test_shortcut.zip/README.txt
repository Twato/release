AI Camera Test Shortcut

Target folder:
/home/toto/AI_CAMERA_TEST_YOLO_ROI

Supported filenames:
- T47_Maintest_UI.py
- T47_MainTest_UI.py
- T47.py

Install:
  chmod +x install_t47_test_shortcut.sh
  ./install_t47_test_shortcut.sh

Desktop shortcut:
- AI Camera Test

Behavior:
- Starts Mock_API_V1/app.py if it is not already running.
- Reuses Mock API if T55 or another process already started it.
- Stops Mock API on exit only if this Test launcher started it.
